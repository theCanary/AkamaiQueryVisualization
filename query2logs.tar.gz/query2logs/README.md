This directory should only have QueryVisualization code
